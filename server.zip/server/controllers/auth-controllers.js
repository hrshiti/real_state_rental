const User = require("../models/user-model");

const bcrypt = require("bcryptjs");

// Register function
const register = async (req, res) => {
    try {
        const { username, email, number, password } = req.body;

        // Check if user already exists
        const userExist = await User.findOne({ email });
        if (userExist) {
            return res.status(400).json({ msg: "Email already exists" });
        }

        // Hash the password before storing (Middleware already does this)
        const userCreated = await User.create({
            username,
            email,
            number,
            password, // No need to hash here, it's already hashed in the schema
        });

        res.status(201).json({
            msg: "User registered successfully",
            token: userCreated.generateToken(),
            userId: userCreated._id.toString(),
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: "Internal Server Error" });
    }
};

// Login function
const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check if user exists
        const userExist = await User.findOne({ email });
        if (!userExist) {
            return res.status(400).json({ msg: "Invalid email or password" });
        }

        // Compare hashed password
        const isMatch = await bcrypt.compare(password, userExist.password);
        if (!isMatch) {
            return res.status(401).json({ msg: "Invalid email or password" });
        }

        // If successful, return token and user ID
        res.status(200).json({
            msg: "Login successful",
            token: userExist.generateToken(),
            userId: userExist._id.toString(),
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: "Internal Server Error" });
    }
};


//registration data get api
const registerdata = async(req,res)=>{
try {
    const response = await User.find()
    if(!response){
        res.status(404).json({msg:"data not found"})
        return
    }
    res.status(200).json({msg:response})
} catch (error) {
    console.log(`services : ${error}`)
}
}



//user data


module.exports = { register, login, registerdata};
